package kr.basic.abookz.entity.member;

public enum RoleEnum {
  Role_Admin, Role_Manager, Role_User
}
