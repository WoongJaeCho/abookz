package kr.basic.abookz.entity;

public enum RoleEntity {
  Role_Admin, Role_Manager, Role_User
}
